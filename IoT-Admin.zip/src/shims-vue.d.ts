declare module '*.vue' {
  import Vue from 'vue'
  export default Vue
}
declare module 'clonedeep'
declare module 'v-charts'
