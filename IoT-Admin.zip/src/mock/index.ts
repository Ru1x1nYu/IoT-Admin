import Mock from 'mockjs'

