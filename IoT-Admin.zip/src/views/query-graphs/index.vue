<template>
  <div class="app-container">
    <el-form
      ref="formInline"
      :inline="true"
      :model="formInline"
    >
      <el-form-item label="查询的标签">
        <el-select
          v-model="formInline.query.__name__"
          placeholder=""
        >
          <el-option
            label="r_temp_r"
            value="r_temp_r"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="设备地址">
        <el-select
          v-model="formInline.query.address"
          placeholder=""
        >
          <el-option
            label="42001"
            value="42001"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="时间">
        <el-date-picker
          v-model="formInline.date"
          type="datetimerange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          align="right"
        />
      </el-form-item>
      <el-form-item label="间隔">
        <el-select
          v-model="formInline.step"
          placeholder=""
        >
          <el-option
            label="50分钟"
            value="50m"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          @click="onSubmit(formInline)"
        >
          查询
        </el-button>
      </el-form-item>
    </el-form>
    <ve-line
      v-if="isShow"
      :loading="isLoading"
      :data="chartData"
      :data-zoom="[{type: 'inside',show: true, xAxisIndex: [0],start: 0,end: 80},{start: 0,end: 80,height: 20}]"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
import { Form as ElForm } from 'element-ui'
import { getGraphsData } from '@/api/graphs'
import clonedeep from 'clonedeep'
@Component({
  name: 'QueryGraphs'
})

export default class extends Vue {
  // data{}
  private formInline: object = {
    query: {
      address: '42001',
      __name__: 'r_temp_r'
    },
    date: ['2020-02-08T08:00:00.000Z', '2020-02-08T13:00:00.000Z'],
    step: '50m'
  }
  private chartSettings = {
    metrics: ['温度'],
    dimension: ['时间']
  }
  private chartData: any ={
    columns: [],
    rows: []
  }
  private isLoading = true
  private isShow = false

  mounted() {
  }
  private onSubmit() {
    (this.$refs.formInline as ElForm).validate(async(valid: boolean) => {
      if (valid) {
        this.isShow = true
        this.isLoading = true
        const query = clonedeep(this.formInline)
        query.start = query.date[0]
        query.end = query.date[1]
        delete query.date
        query.query = `{address='${query.query.address}',__name__='${query.query.__name__}'}`
        var { data } = await getGraphsData(query)
        var list = data.result[0].values
        this.chartData.columns = ['时间', '温度']
        for (let i in list) {
          this.chartData.rows[i] = {
            '时间': new Date(list[i][0] * 1000).toLocaleString(),
            '温度': Number(list[i][1])
          }
        }
        this.isLoading = false
        // this.chartData.columns = ['日期', '访问用户', '下单用户', '下单率']
        // this.chartData.rows = [
        //   { '日期': '1/1', '访问用户': 1393, '下单用户': 1093, '下单率': 0.32 },
        //   { '日期': '1/2', '访问用户': 3530, '下单用户': 3230, '下单率': 0.26 },
        //   { '日期': '1/3', '访问用户': 2923, '下单用户': 2623, '下单率': 0.76 },
        //   { '日期': '1/4', '访问用户': 1723, '下单用户': 1423, '下单率': 0.49 },
        //   { '日期': '1/5', '访问用户': 3792, '下单用户': 3492, '下单率': 0.323 },
        //   { '日期': '1/6', '访问用户': 4593, '下单用户': 4293, '下单率': 0.78 }
        // ]
        console.log(this.chartData)
      } else {
        alert('error submit!!')
        return false
      }
    })
  }
}
</script>
<style lang="scss">
.app-container{
  h2{
    small{
      font-size: 60%;
      font-weight: normal;
    }
  }
  .area-content{
    .el-card__body{
      display: flex;
      padding: 15px;
      flex-wrap: wrap;
      justify-content: flex-start;
    }
    .card-item{
      width: 100px;
      margin: 5px 5px;
    }
  }
  .isUnknow{
    background-color: #ccc;
  }
}
</style>
